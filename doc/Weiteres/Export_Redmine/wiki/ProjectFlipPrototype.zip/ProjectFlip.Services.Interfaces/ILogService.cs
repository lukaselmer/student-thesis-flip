﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace ProjectFlip.Services.Interfaces
{
    public interface ILogService
    {
        void Log(string message);
    }
}
